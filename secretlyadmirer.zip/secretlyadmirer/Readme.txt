This is a script that you can send message to your friends without giving your information. Hope your know whit is thinking your friends about you.
Don't worry there is a table were we collect all message giving device.



open all file and change http://secretlyadmirer.me/ with your domain and root foldes.
and don't forget to chage mysql ditels.
and insert the sql file into your database.